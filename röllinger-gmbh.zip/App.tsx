import React from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { About } from './components/About'; // ScrollyTelling
import { Services } from './components/Services'; // Soft Grid
import { ParallaxSection } from './components/ParallaxSection';
import { Portfolio } from './components/Portfolio'; // Carousel
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-page text-primary selection:bg-brand-green selection:text-primary font-sans overflow-x-hidden">
      <Navigation />
      
      <main>
        <Hero />
        <About />
        <Services />
        <ParallaxSection />
        <Portfolio />
        <Testimonials />
        <Contact />
      </main>

      <Footer />
    </div>
  );
};

export default App;