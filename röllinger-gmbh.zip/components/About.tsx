import React, { useRef, useState, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';

const features = [
  {
    id: 1,
    title: "Handwerk & Präzision",
    description: "Unsere Wurzeln liegen im soliden Schweizer Handwerk. Bei Renovationen und Umbauten setzen wir auf langlebige Materialien und Detailgenauigkeit, die man spüren kann.",
    image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=80&w=2069&auto=format&fit=crop"
  },
  {
    id: 2,
    title: "Natur & Umgebung",
    description: "Ein Garten ist mehr als Grünfläche. Er ist Rückzugsort. Wir pflegen und gestalten Aussenbereiche so, dass sie sich harmonisch in die Umgebung einfügen.",
    image: "https://images.unsplash.com/photo-1585320262218-e4eb317029a3?q=80&w=2070&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "Service & Vertrauen",
    description: "Als Familienunternehmen stehen wir für direkte Kommunikation. Facility Management bedeutet für uns: Wir kümmern uns, als wäre es unser eigenes Zuhause.",
    image: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=2032&auto=format&fit=crop"
  }
];

export const About: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState(0);

  return (
    <section id="expertise" className="bg-page relative">
      <div className="container mx-auto px-6 md:px-12">
        {/* Fix: Removed items-start so columns stretch to equal height */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
          
          {/* Left Column: Sticky Text */}
          {/* Fix: Added h-full so the sticky container has room to scroll */}
          <div className="hidden lg:block relative h-full">
            <div className="sticky top-0 h-screen flex flex-col justify-center">
              <span className="font-sans text-xs tracking-[0.2em] uppercase text-secondary mb-8 block pl-1">Unsere Philosophie</span>
              
              <div className="relative h-64"> 
                {features.map((feature, index) => (
                  <motion.div
                    key={feature.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ 
                      opacity: activeFeature === index ? 1 : 0.1, 
                      y: activeFeature === index ? 0 : 20,
                      scale: activeFeature === index ? 1 : 0.95,
                      filter: activeFeature === index ? 'blur(0px)' : 'blur(4px)',
                    }}
                    transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute top-0 left-0 w-full"
                  >
                    <h2 className="font-serif text-5xl md:text-6xl text-primary mb-6 leading-[1.1]">
                      {feature.title}
                    </h2>
                    <p className="font-sans text-lg text-secondary leading-relaxed max-w-md">
                      {feature.description}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Scrolling Images */}
          <div className="flex flex-col gap-0 py-24 md:py-0">
            {features.map((feature, index) => (
              <ImageCard 
                key={feature.id} 
                feature={feature} 
                index={index} 
                setActiveFeature={setActiveFeature} 
              />
            ))}
          </div>

        </div>
      </div>
    </section>
  );
};

// Helper component to detect view
const ImageCard = ({ feature, index, setActiveFeature }: any) => {
  const ref = useRef(null);
  // Fix: Removed amount: 0.5 to prevent conflict with the margin
  // This configuration creates a trigger line exactly in the center of the viewport
  const isInView = useInView(ref, { margin: "-50% 0px -50% 0px" });

  useEffect(() => {
    if (isInView) {
      setActiveFeature(index);
    }
  }, [isInView, index, setActiveFeature]);

  return (
    <div ref={ref} className="min-h-screen flex items-center justify-center py-10">
      <div className="w-full relative rounded-soft overflow-hidden h-[70vh] shadow-2xl shadow-stone-200/50 group">
        <img 
          src={feature.image} 
          alt={feature.title} 
          className="w-full h-full object-cover transition-transform duration-[1.5s] ease-out group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-500" />
        
        {/* Mobile Text Overlay (Visible only on small screens) */}
        <div className="lg:hidden absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-8 flex flex-col justify-end">
          <span className="text-white/80 text-xs font-bold uppercase tracking-widest mb-2">0{index + 1}</span>
          <h3 className="text-white font-serif text-3xl mb-3">{feature.title}</h3>
          <p className="text-white/90 font-sans text-sm leading-relaxed">{feature.description}</p>
        </div>
      </div>
    </div>
  );
};