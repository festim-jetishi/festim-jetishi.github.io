import React, { useRef } from 'react';
import { ArrowRight } from 'lucide-react';

const projects = [
  { id: 1, title: 'Villa am See', category: 'Renovation', image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?q=80&w=1000' },
  { id: 2, title: 'Stadtgarten Zug', category: 'Gartenbau', image: 'https://images.unsplash.com/photo-1585320262218-e4eb317029a3?q=80&w=1000' },
  { id: 3, title: 'Geschäftshaus Baar', category: 'Facility', image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1000' },
  { id: 4, title: 'Attikawohnung', category: 'Innenausbau', image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?q=80&w=1000' },
];

export const Portfolio: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <section id="portfolio" className="bg-page py-32 overflow-hidden">
      <div className="container mx-auto px-6 md:px-12 mb-12 flex items-end justify-between">
        <div>
          <span className="font-sans text-sm tracking-widest uppercase text-secondary mb-4 block">Portfolio</span>
          <h2 className="font-serif text-5xl text-primary">Ausgewählte Arbeiten</h2>
        </div>
        <div className="hidden md:flex gap-2 text-primary items-center text-sm font-medium">
          Drag to explore <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Carousel Container */}
      <div 
        className="overflow-x-auto scrollbar-hide cursor-drag"
        ref={scrollRef}
      >
        <div className="flex gap-8 px-6 md:px-12 w-max pb-12">
          {projects.map((project) => (
            <div 
              key={project.id}
              className="relative w-[300px] md:w-[450px] aspect-[4/5] rounded-soft overflow-hidden group"
            >
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <span className="text-brand-green text-xs font-bold uppercase tracking-widest mb-2">{project.category}</span>
                <h3 className="text-white font-serif text-2xl">{project.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};