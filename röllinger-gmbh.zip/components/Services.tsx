import React from 'react';
import { Home, Leaf, Hammer, Trash2, Building2, Shovel, ArrowUpRight } from 'lucide-react';

const services = [
  {
    title: 'Hauswartung',
    label: '24/7 Service',
    icon: Home
  },
  {
    title: 'Gartenpflege',
    label: 'Grünflächen',
    icon: Leaf
  },
  {
    title: 'Umbauten',
    label: 'Renovation',
    icon: Hammer
  },
  {
    title: 'Management',
    label: 'Facility',
    icon: Building2
  },
  {
    title: 'Rückbau',
    label: 'Entsorgung',
    icon: Trash2
  },
  {
    title: 'Immobilien',
    label: 'Handel',
    icon: Shovel
  },
];

export const Services: React.FC = () => {
  return (
    <section id="services" className="bg-page py-32">
      <div className="container mx-auto px-6 md:px-12">
        <div className="mb-20 max-w-2xl">
          <span className="font-sans text-sm tracking-widest uppercase text-secondary mb-4 block">Dienstleistungen</span>
          <h2 className="font-serif text-5xl text-primary leading-tight">
            Kompetenz in <br/>jedem Bereich.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group relative bg-card rounded-soft p-10 aspect-square flex flex-col justify-between transition-all duration-slow hover:bg-stone-200/50"
            >
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors duration-500">
                  <service.icon className="w-5 h-5" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-tertiary group-hover:text-primary transition-colors duration-500" />
              </div>

              <div>
                <span className="block font-sans text-xs font-bold tracking-widest uppercase text-secondary mb-3 opacity-60">
                  {service.label}
                </span>
                <h3 className="font-serif text-3xl text-primary">
                  {service.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};