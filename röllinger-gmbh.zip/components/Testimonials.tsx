import React from 'react';
import { Star } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section className="bg-page py-32 border-t border-stone-100">
      <div className="container mx-auto px-6 md:px-12 text-center">
        <span className="font-sans text-sm tracking-widest uppercase text-secondary mb-12 block">Referenzen</span>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            { quote: "Eine unglaubliche Transformation unseres Gartens. Das Team war professionell und pünktlich.", author: "Familie Müller" },
            { quote: "Die Renovation wurde genau nach unseren Vorstellungen umgesetzt. Sehr empfehlenswert.", author: "Thomas Huber" },
            { quote: "Zuverlässiges Facility Management. Wir müssen uns um nichts mehr kümmern.", author: "Liegenschaften AG" }
          ].map((t, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, idx) => (
                  <Star key={idx} className="w-4 h-4 fill-brand-green text-brand-green" />
                ))}
              </div>
              <p className="font-serif text-2xl text-primary italic mb-6 leading-relaxed">"{t.quote}"</p>
              <span className="text-sm font-bold uppercase tracking-widest text-secondary">{t.author}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};